const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

let todos = [];

app.get('/api/todos', (req, res) => {
  res.json(todos);
});

app.post('/api/todos', (req, res) => {
  const { task } = req.body;
  if (task) {
    todos.push({ task });
    res.status(201).json({ message: 'Task added.' });
  } else {
    res.status(400).json({ message: 'Task is required.' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});