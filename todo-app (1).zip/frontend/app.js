document.getElementById('todo-form').addEventListener('submit', function (e) {
  e.preventDefault();
  const taskInput = document.getElementById('task');
  const task = taskInput.value.trim();
  if (task) {
    const li = document.createElement('li');
    li.textContent = task;
    document.getElementById('task-list').appendChild(li);
    taskInput.value = '';
  }
});